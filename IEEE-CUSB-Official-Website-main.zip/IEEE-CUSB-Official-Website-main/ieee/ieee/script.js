const form = document.querySelector('form');
const submitBtn = document.getElementById('sub');

submitBtn.addEventListener('click', (event) => {
  event.preventDefault(); // Prevent form submission
});
